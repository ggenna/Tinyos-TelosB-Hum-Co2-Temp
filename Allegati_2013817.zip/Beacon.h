//header file

#ifndef BEACON_H
#define BEACON_H

#define TIME_BEACON 16000
#define TIMER_WAKEUP 1000
#define TIMER_WAIT 2000
#define MAX_SLAVE 10 
#define TIMER_SCANNER 30000

//predefined structure

typedef nx_struct radio_count_msg {
  nx_uint16_t counter;
} radio_count_msg_t;

//predefined structure ends

// Structure of the Beacon Message
typedef struct beaconMsg 
{
  uint8_t sndId;  // Id of Message Sender
  uint16_t nextBeaconTime;  // local Clock of sender
  uint8_t beaconVector[MAX_SLAVE]; //beacon vector of wireless network
  
  uint16_t temp;
  uint16_t hum;
 
  uint16_t stato; // Automatic(0) , Manual ( 1 o 2 )  User Command 
	
  uint16_t light_TSR;  // total solar radiation
  uint16_t light_PAR; // photosynthetically active radiation
  uint16_t detach; // Rivelatore
  
  uint8_t myfather;

} beaconMsg;	   // 29-byte payload

typedef beaconMsg * beaconMsgPtr;

typedef struct data_t 
{
  uint8_t slave;  // Id of Message Sender
  uint8_t posInBeacon;
} data_t;	   

//typedef beaconMsg * beaconMsgPtr;

enum { 
AM_BEACONMSG=38,
AM_BEACONMSGUART=39
};   // please change if needed

enum utente{
DOWN=1,
UP=2

};

#endif
